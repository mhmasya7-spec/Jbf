package com.example.platehunter

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Base64
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** Records a complete street as 16 kHz mono PCM, then transcribes it once with Deepgram. */
class DeepgramBatchRecorder(
    private val onText: (String) -> Unit,
    private val onStatus: (String) -> Unit
) {
    private val running = AtomicBoolean(false)
    private val audio = ByteArrayOutputStream()
    private var recorder: AudioRecord? = null
    private var audioThread: Thread? = null
    @Volatile private var stoppedByUser = false

    fun start() {
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) { onStatus("تسجيل الصوت غير مدعوم على هذا الجهاز"); return }
        try {
            val r = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, 16000,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 8192))
            if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); onStatus("تعذر تهيئة الميكروفون"); return }
            recorder = r
            synchronized(audio) { audio.reset() }
            stoppedByUser = false
            r.startRecording(); running.set(true)
            audioThread = Thread {
                val buf = ByteArray(4096)
                while (running.get()) {
                    val n = try { r.read(buf, 0, buf.size) } catch (_: Exception) { -1 }
                    if (n > 0) synchronized(audio) { audio.write(buf, 0, n) }
                }
            }.apply { name = "PlateHunterStreetRecorder"; start() }
            onStatus("يسجل الشارع كاملًا… اضغط إيقاف للتفريغ")
        } catch (e: Exception) { onStatus("تعذر بدء التسجيل: ${e.message}") }
    }

    fun stopAndTranscribe(apiKey: String, useGemini: Boolean = false) {
        if (!running.getAndSet(false)) return
        stoppedByUser = true
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { audioThread?.join(500) } catch (_: Exception) {}
        audioThread = null
        val bytes = synchronized(audio) { audio.toByteArray() }
        if (bytes.isEmpty()) { onStatus("التسجيل فارغ؛ جرّب مرة أخرى"); return }
        onStatus("انتهى التسجيل (${bytes.size / 32000} ثانية تقريبًا)، جاري تفريغ الشارع…")
        Thread {
            try {
                val client = OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(180, TimeUnit.SECONDS).writeTimeout(180, TimeUnit.SECONDS)
                    .callTimeout(210, TimeUnit.SECONDS).build()
                val transcript = if (useGemini) {
                    // Split long street recordings into small chunks to avoid request timeouts and huge inline payloads.
                    val chunkBytes = 30 * 16000 * 2 // 30 seconds, 16 kHz, mono, 16-bit PCM
                    val totalChunks = (bytes.size + chunkBytes - 1) / chunkBytes
                    val output = StringBuilder()
                    val prompt = "فرّغ هذا الجزء من التسجيل الصوتي العربي كما قيل، دون تلخيص. أعد النص فقط، مع الحفاظ على أسماء الحروف والأرقام المنطوقة وأسماء أنواع المركبات إن وجدت."
                    for (index in 0 until totalChunks) {
                        val start = index * chunkBytes
                        val end = minOf(bytes.size, start + chunkBytes)
                        val chunk = bytes.copyOfRange(start, end)
                        onStatus("جاري تفريغ الشارع بواسطة Gemini… الجزء ${index + 1} من $totalChunks")
                        val wav = pcmToWav(chunk, 16000, 1, 16)
                        val encoded = Base64.getEncoder().encodeToString(wav)
                        val parts = org.json.JSONArray().put(JSONObject().put("text", prompt)).put(
                            JSONObject().put("inline_data", JSONObject().put("mime_type", "audio/wav").put("data", encoded))
                        )
                        val body = JSONObject().put("contents", org.json.JSONArray().put(JSONObject().put("parts", parts)))
                            .put("generationConfig", JSONObject().put("temperature", 0))
                        val req = Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=$apiKey")
                            .header("Content-Type", "application/json")
                            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
                        val partText = client.newCall(req).execute().use { response ->
                            val payload = response.body?.string().orEmpty()
                            if (!response.isSuccessful) throw IllegalStateException("Gemini HTTP ${response.code} في الجزء ${index + 1}: ${payload.take(220)}")
                            val root = JSONObject(payload)
                            root.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                                ?.let { arr -> (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.optString("text") }.joinToString(" ") }.orEmpty()
                        }
                        if (partText.isNotBlank()) { if (output.isNotEmpty()) output.append(' '); output.append(partText.trim()) }
                    }
                    output.toString()
                } else {
                    val url = "https://api.deepgram.com/v1/listen?model=nova-3&language=ar&encoding=linear16&sample_rate=16000&channels=1&smart_format=true&punctuate=true" +
                        (PlateParser.letterNames + listOf("وانيت", "تاكسي", "نقل", "ميكروباص", "يامه", "لوحة")).joinToString("") { "&keyterm=" + URLEncoder.encode(it, "UTF-8") }
                    val request = Request.Builder().url(url).header("Authorization", "Token $apiKey")
                        .header("Content-Type", "audio/linear16; rate=16000; channels=1")
                        .post(bytes.toRequestBody("audio/linear16".toMediaType())).build()
                    client.newCall(request).execute().use { response ->
                        if (!response.isSuccessful) throw IllegalStateException("Deepgram HTTP ${response.code}: ${response.body?.string()?.take(250)}")
                        val root = JSONObject(response.body?.string().orEmpty())
                        root.optJSONObject("results")?.optJSONArray("channels")?.optJSONObject(0)
                            ?.optJSONArray("alternatives")?.optJSONObject(0)?.optString("transcript").orEmpty()
                    }
                }
                if (transcript.isBlank()) onStatus("${if (useGemini) "Gemini" else "Deepgram"} لم يستخرج كلامًا من التسجيل") else onText(transcript)
            } catch (e: Exception) { onStatus("فشل تفريغ التسجيل: ${e.message ?: "تحقق من الاتصال والمفتاح"}") }
        }.apply { name = "PlateHunterBatchTranscription"; start() }
    }

    private fun pcmToWav(pcm: ByteArray, sampleRate: Int, channels: Int, bitsPerSample: Int): ByteArray {
        val byteRate = sampleRate * channels * bitsPerSample / 8
        val out = ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN)
        out.put("RIFF".toByteArray(Charsets.US_ASCII)); out.putInt(36 + pcm.size)
        out.put("WAVE".toByteArray(Charsets.US_ASCII)); out.put("fmt ".toByteArray(Charsets.US_ASCII))
        out.putInt(16); out.putShort(1); out.putShort(channels.toShort()); out.putInt(sampleRate)
        out.putInt(byteRate); out.putShort((channels * bitsPerSample / 8).toShort()); out.putShort(bitsPerSample.toShort())
        out.put("data".toByteArray(Charsets.US_ASCII)); out.putInt(pcm.size); out.put(pcm)
        return out.array()
    }

    fun cancel() {
        running.set(false)
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null; audioThread = null
    }
}
